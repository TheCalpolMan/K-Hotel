#ifndef K_HOTEL_ARJUN_H
#define K_HOTEL_ARJUN_H

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void Checkin();

#endif //K_HOTEL_ARJUN_H
