//
// Created by Jacob on 13/11/2020.
//

#ifndef K_HOTEL_JACOB_H
#define K_HOTEL_JACOB_H

void strtoint(char source[], int dest[], int lengthofconversion);
void inttostr(int source[], char dest[], int lengthofconversion);
void booktable();
void CheckOut();

#endif //K_HOTEL_JACOB_H
